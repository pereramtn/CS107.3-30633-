﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter height");
            int height = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter width");
            int width = Convert.ToInt32(Console.ReadLine());
            CalArea(height, width);
            Console.ReadLine();
        }
        static void CalArea(int width, int height)
        {
            int area;
            area = height * width;
            Console.WriteLine("The area is " + area);

        }
    }
}
