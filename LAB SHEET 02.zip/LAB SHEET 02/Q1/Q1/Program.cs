﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1
{
        class Book
        {
            public string Title;
            public string Author;
        }

        class Program
        {
            static void Main(string[] args)
            {
                Book myBook = new Book();

                myBook.Title = "The Vendor Of Sweets";
                myBook.Author = "R.K. Narayan";

                Console.WriteLine("Book Title: " + myBook.Title);
                Console.WriteLine("Author: " + myBook.Author);

                Console.ReadLine(); 

            }
        }
}
