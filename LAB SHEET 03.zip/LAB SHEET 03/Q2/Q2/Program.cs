﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
    using System;

    public class Employee
    {
       
        public int EmployeeID;
        public string FullName;
        public double Salary;

    
        public Employee(int employeeID, string fullName, double salary)
        {
            EmployeeID = employeeID;
            FullName = fullName;
            Salary = salary;
        }

        
        public void DisplayEmployeeInfo()
        {
            Console.WriteLine($"Employee ID: {EmployeeID}");
            Console.WriteLine($"Full Name: {FullName}");
            Console.WriteLine($"Salary: ${Salary}");
            Console.ReadLine();
        }
        
    }

    class Program
    {
        static void Main(string[] args)
        {
            
            Employee emp = new Employee(101, "John Doe", 50000);

            Console.WriteLine($"Employee ID: {emp.EmployeeID}");
            Console.ReadLine();

            emp.FullName = "Jane Smith";

            Console.WriteLine($"Updated Full Name: {emp.FullName}");
            Console.ReadLine();

            emp.DisplayEmployeeInfo();

        }

    }
    
   
}
